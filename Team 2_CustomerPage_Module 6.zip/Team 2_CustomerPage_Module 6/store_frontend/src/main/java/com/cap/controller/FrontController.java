package com.cap.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cap.bean.Customer;

@RestController
public class FrontController {

	@RequestMapping("/updateProfile")
	public Customer Profile(@RequestParam String name, @RequestParam String email, @RequestParam String gender, @RequestParam String phone) {
		
		RestTemplate rt=new RestTemplate();
		Customer cp= rt.getForObject("http://localhost:9004/profile?name="+name+"&email="+email+"&gender="+gender+"&phone="+phone, Customer.class);
		return cp;
		
	}
	
}
