package com.cap.service;


public interface ICustomerService {
	
	public void updateProfile(String name, String email, String gender, String phone);

}
