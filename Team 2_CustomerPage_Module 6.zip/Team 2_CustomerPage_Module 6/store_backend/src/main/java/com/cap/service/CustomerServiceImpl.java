package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.bean.Customer;
import com.cap.repo.ICustomerRepo;


@Service
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	private ICustomerRepo repo;

	@Override
	public void updateProfile(String name, String email, String gender, String phone) {
		Customer c= new Customer();
		c.setName(name);
		c.setEmail(email);
		c.setGender(gender);
		c.setPhone(phone);
		repo.save(c);
	}

	
	}


